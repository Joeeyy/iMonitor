/* include/config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Define to 1 if you have the <arpa/inet.h> header file. */
#define HAVE_ARPA_INET_H 1

/* Define to 1 if you have the `bzero' function. */
#define HAVE_BZERO 1

/* Define to 1 if you have the <fcntl.h> header file. */
#define HAVE_FCNTL_H 1

/* Define to 1 if you have the `fork' function. */
#define HAVE_FORK 1

/* Define to 1 if you have the `gethostbyname' function. */
#define HAVE_GETHOSTBYNAME 1

/* Define to 1 if you have the `gettimeofday' function. */
#define HAVE_GETTIMEOFDAY 1

/* Define to 1 if you have the `inet_ntoa' function. */
#define HAVE_INET_NTOA 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the `dl' library (-ldl). */
#define HAVE_LIBDL 1

/* Define to 1 if you have the `ldap' library (-lldap). */
#define HAVE_LIBLDAP 1

/* Define to 1 if you have the `pam' library (-lpam). */
#define HAVE_LIBPAM 1

/* Define to 1 if you have the `pam_misc' library (-lpam_misc). */
#define HAVE_LIBPAM_MISC 1

/* Define to 1 if you have the `pthread' library (-lpthread). */
#define HAVE_LIBPTHREAD 1

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have the `memset' function. */
#define HAVE_MEMSET 1

/* Define to 1 if you have the <netdb.h> header file. */
#define HAVE_NETDB_H 1

/* Define to 1 if you have the <netinet/in.h> header file. */
#define HAVE_NETINET_IN_H 1

/* Define to 1 if your system has a GNU libc compatible `realloc' function,
   and to 0 otherwise. */
#define HAVE_REALLOC 1

/* Define to 1 if you have the `select' function. */
#define HAVE_SELECT 1

/* Define to 1 if you have the `socket' function. */
#define HAVE_SOCKET 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the `strdup' function. */
#define HAVE_STRDUP 1

/* Define to 1 if you have the `strftime' function. */
#define HAVE_STRFTIME 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the `strtol' function. */
#define HAVE_STRTOL 1

/* Define to 1 if you have the <syslog.h> header file. */
#define HAVE_SYSLOG_H 1

/* Define to 1 if you have the <sys/ioctl.h> header file. */
#define HAVE_SYS_IOCTL_H 1

/* Define to 1 if you have the <sys/select.h> header file. */
#define HAVE_SYS_SELECT_H 1

/* Define to 1 if you have the <sys/socket.h> header file. */
#define HAVE_SYS_SOCKET_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/time.h> header file. */
#define HAVE_SYS_TIME_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have <sys/wait.h> that is POSIX.1 compatible. */
#define HAVE_SYS_WAIT_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if you have the `vfork' function. */
#define HAVE_VFORK 1

/* Define to 1 if you have the <vfork.h> header file. */
/* #undef HAVE_VFORK_H */

/* Define to 1 if `fork' works. */
#define HAVE_WORKING_FORK 1

/* Define to 1 if `vfork' works. */
#define HAVE_WORKING_VFORK 1

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "BUG-REPORT-ADDRESS"

/* Define to the full name of this package. */
#define PACKAGE_NAME "FULL-PACKAGE-NAME"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "FULL-PACKAGE-NAME VERSION"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "full-package-name"

/* Define to the version of this package. */
#define PACKAGE_VERSION "VERSION"

/* Define to the type of arg 1 for `select'. */
#define SELECT_TYPE_ARG1 int

/* Define to the type of args 2, 3 and 4 for `select'. */
#define SELECT_TYPE_ARG234 (fd_set *)

/* Define to the type of arg 5 for `select'. */
#define SELECT_TYPE_ARG5 (struct timeval *)

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Define to 1 if you can safely include both <sys/time.h> and <time.h>. */
#define TIME_WITH_SYS_TIME 1

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* Define default value of pathname for configuration file */
#ifdef FREEBSD
#define SS5_CONFIG_FILE    "/usr/local/etc/opt/ss5/ss5.conf"
#else
#define SS5_CONFIG_FILE    "/etc/opt/ss5/ss5.conf"
#endif

/* Define default value of pathname for HA file */
#ifdef FREEBSD
#define SS5_PEERS_FILE     "/usr/local/etc/opt/ss5/ss5.ha"
#else
#define SS5_PEERS_FILE     "/etc/opt/ss5/ss5.ha"
#endif

/* Define default value of pathname for password file */
#ifdef FREEBSD
#define SS5_PASSWORD_FILE  "/usr/local/etc/opt/ss5/ss5.passwd"
#else
#define SS5_PASSWORD_FILE  "/etc/opt/ss5/ss5.passwd"
#endif

/* Define default value of pathname for log file */
#define SS5_LOG_FILE  "/var/log/ss5/ss5.log"

/* Define default value of pathname for pid file */
#define SS5_PID_FILE  "/var/run/ss5/ss5.pid"

/* Define default value of path for profile files */
#ifdef FREEBSD
#define SS5_PROFILE_PATH   "/usr/local/etc/opt/ss5"
#else
#define SS5_PROFILE_PATH   "/etc/opt/ss5"
#endif

/* Define default value of path for trace files */
#define SS5_TRACE_PATH   "/var/log/ss5"

/* Define default value of path modules */
#ifdef FREEBSD
#define SS5_LIB_PATH       "/usr/local/lib"
#else
#define SS5_LIB_PATH       "/usr/lib"
#endif

/* Define default value of bind addr */
#define SS5_DEFAULT_ADDR   "0.0.0.0"

/* Define default value of bind port */
#define SS5_DEFAULT_PORT   "1080"

/* Define default value of user process */
#define SS5_DEFAULT_USER   "nobody"

/* Define to `__inline__' or `__inline' if that's what the C compiler
   calls it, or to nothing if 'inline' is not supported under any name.  */
#ifndef __cplusplus
/* #undef inline */
#endif

/* Define to `int' if <sys/types.h> does not define. */
/* #undef pid_t */

/* Define to rpl_realloc if the replacement function should be used. */
/* #undef realloc */

/* Define as `fork' if `vfork' does not work. */
/* #undef vfork */
